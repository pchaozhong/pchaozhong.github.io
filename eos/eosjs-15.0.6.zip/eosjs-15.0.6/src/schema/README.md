# Warning

Some files are generated.

See `eosjs/bin/eosio-abi-update.sh`

Updated as follows:

```bash
cd ~/eosjs/docker && ./up.sh
cd ~/eosjs/bin && ./eosio-abi-update.sh
```
